#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../parser/ast_nodes.h"

#include "./memory.h"


#define MAX_VARIABLES 100


typedef struct {
    char* name;
    double value;  // Changed from int to double
} Variable;

static Variable variables[MAX_VARIABLES];
static int var_count = 0;

// Set or update variable
void set_var(const char* name, double value) {
    for (int i = 0; i < var_count; i++) {
        if (strcmp(variables[i].name, name) == 0) {
            variables[i].value = value;
            return;
        }
    }
    variables[var_count].name = strdup(name);
    variables[var_count].value = value;
    var_count++;
}

// Retrieve variable value
double get_var(const char* name) {
    for (int i = 0; i < var_count; i++) {
        if (strcmp(variables[i].name, name) == 0) {
            return variables[i].value;
        }
    }
    fprintf(stderr, "[Runtime] Undefined variable: %s\n", name);
    exit(1);
}


// Evaluate expressions recursively
double eval_expr(ASTNode* node) {
    if (!node) {
        fprintf(stderr, "[Runtime] NULL node passed to eval_expr\n");
        exit(1);
    }

    switch (node->type) {
        case AST_VAR:
            return get_var(node->var.name);  // Handles undefined vars internally

        case AST_LET:
            return node->let_stmt.value;

        case AST_BINARY: {
            double left = eval_expr(node->binary_expr.left);
            double right = eval_expr(node->binary_expr.right);
            TokenType op = node->binary_expr.op;

            switch (op) {
                case TOKEN_PLUS:
                    return left + right;
                case TOKEN_MINUS:
                    return left - right;
                case TOKEN_STAR:
                    return left * right;
                case TOKEN_SLASH:
                    if (right == 0) {
                        fprintf(stderr, "[Runtime] Division by zero (%.5f / %.5f)\n", left, right);
                        exit(1);
                    }
                    return left / right;
                default:
                    fprintf(stderr, "[Runtime] Unknown binary operator: %d\n", op);
                    exit(1);
            }
        }

        case AST_INDEX: {
            double array = eval_expr(node->index_expr.array);
            double index = eval_expr(node->index_expr.index);
            fprintf(stderr, "[Runtime] Warning: Using 'index' operator [%.2f][%.2f] — not fully implemented\n", array, index);
            return index;  // Placeholder — returns index for now
        }

        default:
            fprintf(stderr, "[Runtime] Unsupported expression type: %d\n", node->type);
            exit(1);
    }
}

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "parser.h"
#include "runtime/memory.h"

static int gcode_mode_active = 0;


static Parser parser;

static void advance() {
    parser.previous = parser.current;
    parser.current = lexer_next_token(parser.lexer);
}

static int match(TokenType type) {
    if (parser.current.type == type) {
        advance();
        return 1;
    }
    return 0;
}


static ASTNode* parse_binary_expression();  // Forward declaration


static ASTNode* parse_primary() {
    // Handle parentheses first
    if (parser.current.type == TOKEN_LPAREN) {
        advance();  // consume '('
        ASTNode* expr = parse_binary_expression();  // parse inner expression
        if (!match(TOKEN_RPAREN)) {
            printf("[Parser] Expected ')' after expression\n");
            exit(1);
        }
        return expr;  // return grouped expression
    }

    // Handle unary minus
    if (parser.current.type == TOKEN_MINUS) {
        advance();  // consume '-'
        ASTNode* right = parse_primary();

        ASTNode* node = malloc(sizeof(ASTNode));
        node->type = AST_BINARY;
        node->binary_expr.op = TOKEN_MINUS;
        node->binary_expr.left = malloc(sizeof(ASTNode));
        node->binary_expr.left->type = AST_LET;
        node->binary_expr.left->let_stmt.name = NULL;
        node->binary_expr.left->let_stmt.value = 0;
        node->binary_expr.right = right;
        return node;
    }

    if (parser.current.type == TOKEN_IDENTIFIER) {
        ASTNode* node = malloc(sizeof(ASTNode));
        node->type = AST_VAR;
        node->var.name = strdup(parser.current.value);
        advance();
        return node;
    } else if (parser.current.type == TOKEN_NUMBER) {
        ASTNode* node = malloc(sizeof(ASTNode));
        node->type = AST_LET;
        node->let_stmt.name = NULL;
        node->let_stmt.value = atof(parser.current.value);
        advance();
        return node;
    } else {
        printf("[Parser] Unexpected token in expression: %s\n", parser.current.value);
        exit(1);
    }
}






static ASTNode* parse_binary_expression() {
    ASTNode* left = parse_primary();

    while (parser.current.type == TOKEN_PLUS || parser.current.type == TOKEN_MINUS ||
           parser.current.type == TOKEN_STAR || parser.current.type == TOKEN_SLASH) {
        TokenType op = parser.current.type;
        advance();
        ASTNode* right = parse_binary_expression();  // Allow chaining like x-20


                ASTNode* node = malloc(sizeof(ASTNode));
        node->type = AST_BINARY;
        node->binary_expr.op = op;
        node->binary_expr.left = left;
        node->binary_expr.right = right;

        left = node;
    }

    return left;
}

double eval_expr(ASTNode* node);

static ASTNode* parse_statement();

static ASTNode* parse_block() {
    if (!match(TOKEN_LBRACE)) {
        printf("[Parser] Expected '{'\n");
        exit(1);
    }

    ASTNode** statements = NULL;
    int capacity = 0, count = 0;

    while (!match(TOKEN_RBRACE)) {
        if (parser.current.type == TOKEN_EOF) {
            printf("[Parser] Unexpected EOF in block\n");
            exit(1);
        }

        if (count >= capacity) {
            capacity = capacity == 0 ? 4 : capacity * 2;
            statements = realloc(statements, capacity * sizeof(ASTNode*));
        }

        statements[count++] = parse_statement();
    }

    ASTNode* node = malloc(sizeof(ASTNode));
    node->type = AST_BLOCK;
    node->block.statements = statements;
    node->block.count = count;
    return node;
}
static ASTNode* parse_for() {
    advance(); // skip 'for'

    if (parser.current.type != TOKEN_IDENTIFIER) {
        printf("[Parser] Expected variable after 'for'\n");
        exit(1);
    }
    char* var = strdup(parser.current.value);
    advance();

    if (!match(TOKEN_EQUAL)) {
        printf("[Parser] Expected '=' after loop var\n");
        exit(1);
    }

    ASTNode* from_expr = parse_binary_expression();
    double from = eval_expr(from_expr);
    free_ast(from_expr);

    if (parser.current.type != TOKEN_DOTDOT) {
        printf("[Parser] Expected '..' in loop range\n");
        exit(1);
    }
    advance();

    ASTNode* to_expr = parse_binary_expression();
    double to = eval_expr(to_expr);
    free_ast(to_expr);

    ASTNode* body = parse_block();

    ASTNode* node = malloc(sizeof(ASTNode));
    node->type = AST_FOR;
    node->for_stmt.var = var;
    node->for_stmt.from = from;
    node->for_stmt.to = to;
    node->for_stmt.body = body;
    return node;
}





static ASTNode* parse_let() {
    advance();  // skip 'let'

    if (parser.current.type != TOKEN_IDENTIFIER) {
        printf("[Parser] Expected identifier after 'let'\n");
        exit(1);
    }

    char* name = strdup(parser.current.value);
    advance();

    if (!match(TOKEN_EQUAL)) {
        printf("[Parser] Expected '=' after variable name\n");
        exit(1);
    }

    ASTNode* expr = parse_binary_expression();  // support full expressions like -33, x+1, 2*3

    double value = eval_expr(expr);  // evaluate expression to get a value
    free_ast(expr);  // cleanup after evaluation

    ASTNode* node = malloc(sizeof(ASTNode));
    node->type = AST_LET;
    node->let_stmt.name = name;
    node->let_stmt.value = value;
    return node;
}

static ASTNode* parse_gcode() {
// Start grouping multiple GCODE words from the same line
char line[256] = {0};
int line_pos = 0;

while (parser.current.type == TOKEN_GCODE_WORD) {
    if (line_pos > 0) line[line_pos++] = ' ';  // add space between tokens
    int len = snprintf(line + line_pos, sizeof(line) - line_pos, "%s", parser.current.value);
    line_pos += len;
    advance();
}
char* code = strdup(line);


    GArg* args = NULL;
    int count = 0, capacity = 0;

    while (parser.current.type == TOKEN_IDENTIFIER) {
        char* key = strdup(parser.current.value);
        advance();

        ASTNode* index = NULL;
if (parser.current.type == TOKEN_LBRACKET) {
    advance();
    index = parse_binary_expression();  // handles x-20, x+2, -20, etc.
    if (!match(TOKEN_RBRACKET)) {
        printf("[Parser] Expected ']'\n");
        exit(1);
    }
}


        if (count >= capacity) {
            capacity = capacity == 0 ? 4 : capacity * 2;
            args = realloc(args, capacity * sizeof(GArg));
        }
        args[count++] = (GArg){key, index};
    }

    ASTNode* node = malloc(sizeof(ASTNode));
    node->type = AST_GCODE;
    node->gcode_stmt.code = code;
    node->gcode_stmt.args = args;
    node->gcode_stmt.argCount = count;
    gcode_mode_active = 1;

    return node;
}


static ASTNode* parse_gcode_coord_only() {
    GArg* args = NULL;
    int count = 0, capacity = 0;

    while (parser.current.type == TOKEN_IDENTIFIER) {
        char* key = strdup(parser.current.value);
        advance();

        ASTNode* index = NULL;
        if (parser.current.type == TOKEN_LBRACKET) {
            advance();
            index = parse_binary_expression();
            if (!match(TOKEN_RBRACKET)) {
                printf("[Parser] Expected ']'\n");
                exit(1);
            }
        }

        if (count >= capacity) {
            capacity = capacity == 0 ? 4 : capacity * 2;
            args = realloc(args, capacity * sizeof(GArg));
        }
        args[count++] = (GArg){key, index};
    }

    // Assume implicit G1
    ASTNode* node = malloc(sizeof(ASTNode));
    node->type = AST_GCODE;
    node->gcode_stmt.code = strdup("G1");
    node->gcode_stmt.args = args;
    node->gcode_stmt.argCount = count;
    return node;
}


static ASTNode* parse_statement() {
    if (parser.current.type == TOKEN_FOR) return parse_for();
    if (parser.current.type == TOKEN_LET) return parse_let();
    if (parser.current.type == TOKEN_GCODE_WORD) return parse_gcode();
    
    if (parser.current.type == TOKEN_IDENTIFIER && gcode_mode_active)
        return parse_gcode_coord_only();

    printf("[Parser] Unexpected token: %s\n", parser.current.value);
    exit(1);
}


ASTNode* parse_script(const char* source) {
    parser.lexer = lexer_new(source);
    advance();

    ASTNode** statements = NULL;
    int capacity = 0, count = 0;

    while (parser.current.type != TOKEN_EOF) {
        if (count >= capacity) {
            capacity = capacity == 0 ? 4 : capacity * 2;
            statements = realloc(statements, capacity * sizeof(ASTNode*));
        }

        statements[count++] = parse_statement();
    }

    ASTNode* root = malloc(sizeof(ASTNode));
    root->type = AST_BLOCK;
    root->block.statements = statements;
    root->block.count = count;
    return root;
}

void free_ast(ASTNode* node) {
    if (!node) return;

    switch (node->type) {
                case AST_BINARY:
            free_ast(node->binary_expr.left);
            free_ast(node->binary_expr.right);
            break;

        case AST_LET:
            free(node->let_stmt.name);
            break;
        case AST_VAR:
            free(node->var.name);
            break;
        case AST_GCODE:
            free(node->gcode_stmt.code);
            for (int i = 0; i < node->gcode_stmt.argCount; i++) {
                free(node->gcode_stmt.args[i].key);
                free_ast(node->gcode_stmt.args[i].indexExpr);
            }
            free(node->gcode_stmt.args);
            break;
        case AST_FOR:
            free(node->for_stmt.var);
            free_ast(node->for_stmt.body);
            break;
        case AST_BLOCK:
            for (int i = 0; i < node->block.count; i++) {
                free_ast(node->block.statements[i]);
            }
            free(node->block.statements);
            break;
        case AST_INDEX:
            free_ast(node->index_expr.array);
            free_ast(node->index_expr.index);
            break;
        default:
            break;
    }

    free(node);
}

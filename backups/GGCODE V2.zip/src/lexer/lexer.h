#ifndef LEXER_H
#define LEXER_H

#include "token_types.h"

typedef struct {
    TokenType type;
    char* value;
    int line;
    int column;
} Token;

typedef struct {
    const char* source;
    int pos;
    int line;
    int column;
} Lexer;

Lexer* lexer_new(const char* source);
Token lexer_next_token(Lexer* lexer);
void lexer_free(Lexer* lexer);
void token_free(Token token);

#endif // LEXER_H

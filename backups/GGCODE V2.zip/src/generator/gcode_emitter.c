#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gcode_emitter.h"

#include "runtime/evaluator.h"
#include "utils/output_buffer.h"
#include "config.h"

int statement_count = 0;


int get_statement_count() {
    return statement_count;
}

void emit_gcode(ASTNode* node, int debug) {
    switch (node->type) {
        case AST_LET:
            if (debug)
                printf("[Emit] LET %s = %.5f\n", node->let_stmt.name, node->let_stmt.value);
            set_var(node->let_stmt.name, node->let_stmt.value);
            break;

        case AST_GCODE: {
            statement_count++;
            if (debug)
                printf("[Emit] GCODE %s\n", node->gcode_stmt.code);

            static char last_code[16] = "";
            char line[256] = {0};

            // Add line number if enabled
            if (get_enable_n_lines()) {
                snprintf(line, sizeof(line), "N%d ", get_line_number());
                increment_line_number();
            }

            // Only write the G-code command if it's different from the last one
            if (strcmp(node->gcode_stmt.code, "G1") == 0) {
                if (strcmp(last_code, "G1") != 0) {
                    strcat(line, "G1");
                    strcpy(last_code, "G1");
                }
            } else {
                strcat(line, node->gcode_stmt.code);
                strcpy(last_code, node->gcode_stmt.code);
            }

            for (int i = 0; i < node->gcode_stmt.argCount; i++) {
                char segment[64];
                double val = node->gcode_stmt.args[i].indexExpr
                             ? eval_expr(node->gcode_stmt.args[i].indexExpr)
                             : 0.0;

                snprintf(segment, sizeof(segment), " %s%.6g", node->gcode_stmt.args[i].key, val);
                strcat(line, segment);
            }

            if (debug)
                printf("[Line] Final G-code: %s\n", line);
            write_to_output(line);
            break;
        }

        case AST_FOR:
            if (debug)
                printf("[Emit] FOR %s = %.2f .. %.2f\n", node->for_stmt.var, node->for_stmt.from, node->for_stmt.to);
            for (int i = node->for_stmt.from; i <= node->for_stmt.to; i++) {
                set_var(node->for_stmt.var, i);
                emit_gcode(node->for_stmt.body, debug);
            }
            break;

        case AST_BLOCK:
            if (debug)
                printf("[Emit] BLOCK with %d statements\n", node->block.count);
            for (int i = 0; i < node->block.count; i++) {
                emit_gcode(node->block.statements[i], debug);
            }
            break;

        default:
            if (debug)
                printf("[Emit] Skipping unknown node type: %d\n", node->type);
            break;
    }
}

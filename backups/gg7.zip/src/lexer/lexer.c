#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#include "lexer.h"

int LEXER_DEBUG = 0;  // Toggle lexer debug output

Lexer* lexer_new(const char* source) {
    Lexer* lexer = (Lexer*)malloc(sizeof(Lexer));
    lexer->source = source;
    lexer->pos = 0;
    lexer->line = 1;
    lexer->column = 1;
    return lexer;
}

void lexer_free(Lexer* lexer) {
    free(lexer);
}

void token_free(Token token) {
    if (token.value) free(token.value);
}

static void print_token(Token token) {
    if (LEXER_DEBUG) {
        printf("[Lexer] Token: type=%d, value='%s' at line=%d, col=%d\n",
               token.type, token.value, token.line, token.column);
    }
}

static char peek(Lexer* lexer) {
    return lexer->source[lexer->pos];
}

static char peek_next(Lexer* lexer) {
    return lexer->source[lexer->pos + 1];
}

static char advance(Lexer* lexer) {
    char c = lexer->source[lexer->pos++];
    lexer->column++;
    if (c == '\n') {
        lexer->line++;
        lexer->column = 1;
    }
    return c;
}

static void skip_whitespace(Lexer* lexer) {
    while (1) {
        char c = peek(lexer);

        // Skip whitespace
        if (isspace(c)) {
            if (c == '\n') {
                lexer->line++;
                lexer->column = 1;
            }
            advance(lexer);
        }

        // Skip // single-line comments
        else if (c == '/' && peek_next(lexer) == '/') {
            while (peek(lexer) != '\n' && peek(lexer) != '\0') {
                advance(lexer);
            }
        }

        // Skip /* multi-line */ comments
        else if (c == '/' && peek_next(lexer) == '*') {
            advance(lexer);  // consume '/'
            advance(lexer);  // consume '*'
            while (!(peek(lexer) == '*' && peek_next(lexer) == '/') && peek(lexer) != '\0') {
                if (peek(lexer) == '\n') {
                    lexer->line++;
                    lexer->column = 1;
                }
                advance(lexer);
            }
            if (peek(lexer) == '*' && peek_next(lexer) == '/') {
                advance(lexer);  // consume '*'
                advance(lexer);  // consume '/'
            }
        }

        else {
            break;
        }
    }
}


static Token make_token(TokenType type, const char* value, int line, int column) {
    Token token;
    token.type = type;
    token.value = strdup(value);
    token.line = line;
    token.column = column;
    print_token(token);
    return token;
}

Token lexer_next_token(Lexer* lexer) {
    skip_whitespace(lexer);
    int start_pos = lexer->pos;
    int start_col = lexer->column;
    char c = peek(lexer);

    if (c == '\0') return make_token(TOKEN_EOF, "EOF", lexer->line, lexer->column);

    // Handle '..' range operator early
    if (c == '.' && peek_next(lexer) == '.') {
        advance(lexer);
        advance(lexer);
        return make_token(TOKEN_DOTDOT, "..", lexer->line, start_col);
    }

    // Identifiers and keywords
    if (isalpha(c)) {
        while (isalnum(peek(lexer)) || peek(lexer) == '_') advance(lexer);
        int length = lexer->pos - start_pos;
        char* word = strndup(&lexer->source[start_pos], length);

        if (strcmp(word, "let") == 0) return make_token(TOKEN_LET, word, lexer->line, start_col);
        if (strcmp(word, "for") == 0) return make_token(TOKEN_FOR, word, lexer->line, start_col);
        if (strcmp(word, "function") == 0) return make_token(TOKEN_FUNCTION, word, lexer->line, start_col);
        if (strcmp(word, "note") == 0) return make_token(TOKEN_NOTE, word, lexer->line, start_col);

        if (word[0] == 'G' || word[0] == 'M' || word[0] == 'T') return make_token(TOKEN_GCODE_WORD, word, lexer->line, start_col);
        return make_token(TOKEN_IDENTIFIER, word, lexer->line, start_col);
    }

    // Number with optional unary minus (only after '=' or at start of line)
// Number with optional unary minus (only after '=' or at start of line)
if ((c == '-' && (isdigit(peek_next(lexer)) || peek_next(lexer) == '.')) ||
     isdigit(c) || 
     (c == '.' && peek_next(lexer) != '.' && isdigit(peek_next(lexer)))) {


        int allow_unary = 0;
        if (c == '-') {
            // Look back to see if previous char is '=' or we're at line start
            int prev = lexer->pos - 1;
            while (prev > 0 && isspace(lexer->source[prev])) prev--;
            if (prev == 0 || lexer->source[prev] == '=' || lexer->source[prev] == '(' || lexer->source[prev] == '[')
                allow_unary = 1;
        } else {
            allow_unary = 1;
        }

        if (allow_unary) {
            int start = lexer->pos;
            advance(lexer);  // consume '-' or digit or '.'
            while (isdigit(peek(lexer))) advance(lexer);
if (peek(lexer) == '.' && peek_next(lexer) != '.') {
    advance(lexer);
    while (isdigit(peek(lexer))) advance(lexer);
}

            int len = lexer->pos - start;
            char* num = strndup(&lexer->source[start], len);
            return make_token(TOKEN_NUMBER, num, lexer->line, start_col);
        }
    }

    // Symbols and operators
    switch (c) {
        case '+': advance(lexer); return make_token(TOKEN_PLUS, "+", lexer->line, start_col);
        case '-': advance(lexer); return make_token(TOKEN_MINUS, "-", lexer->line, start_col);
        case '*': advance(lexer); return make_token(TOKEN_STAR, "*", lexer->line, start_col);
        case '/': advance(lexer); return make_token(TOKEN_SLASH, "/", lexer->line, start_col);
        case '=':
            advance(lexer);
            if (peek(lexer) == '=') {
                advance(lexer);
                return make_token(TOKEN_EQUAL_EQUAL, "==", lexer->line, start_col);
            }
            return make_token(TOKEN_EQUAL, "=", lexer->line, start_col);
        case '!':
            advance(lexer);
            if (peek(lexer) == '=') {
                advance(lexer);
                return make_token(TOKEN_EQUAL_EQUAL, "!=", lexer->line, start_col);
            }
            break;
        case '<':
            advance(lexer);
            if (peek(lexer) == '=') {
                advance(lexer);
                return make_token(TOKEN_LESS_EQUAL, "<=", lexer->line, start_col);
            }
            return make_token(TOKEN_LESS, "<", lexer->line, start_col);
        case '>':
            advance(lexer);
            if (peek(lexer) == '=') {
                advance(lexer);
                return make_token(TOKEN_GREATER_EQUAL, ">=", lexer->line, start_col);
            }
            return make_token(TOKEN_GREATER, ">", lexer->line, start_col);
        case '(': advance(lexer); return make_token(TOKEN_LPAREN, "(", lexer->line, start_col);
        case ')': advance(lexer); return make_token(TOKEN_RPAREN, ")", lexer->line, start_col);
        case '{': advance(lexer); return make_token(TOKEN_LBRACE, "{", lexer->line, start_col);
        case '}': advance(lexer); return make_token(TOKEN_RBRACE, "}", lexer->line, start_col);
        case '[': advance(lexer); return make_token(TOKEN_LBRACKET, "[", lexer->line, start_col);
        case ']': advance(lexer); return make_token(TOKEN_RBRACKET, "]", lexer->line, start_col);
        case ',': advance(lexer); return make_token(TOKEN_COMMA, ",", lexer->line, start_col);
        case ';': advance(lexer); return make_token(TOKEN_SEMICOLON, ";", lexer->line, start_col);
        case '.': advance(lexer); return make_token(TOKEN_DOT, ".", lexer->line, start_col);
        default: {
            advance(lexer);
            char unknown[2] = {c, '\0'};
            return make_token(TOKEN_UNKNOWN, unknown, lexer->line, start_col);
        }
    }

    return make_token(TOKEN_EOF, "EOF", lexer->line, lexer->column);
}

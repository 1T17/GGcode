// utils/report.h
void print_compilation_report(long input_size, long output_size, double parse_time, double emit_time, long mem_kb, int statement_count);

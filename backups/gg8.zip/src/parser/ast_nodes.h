#ifndef AST_NODES_H
#define AST_NODES_H

#include "../lexer/token_types.h"

typedef struct ASTNode ASTNode;

// G-code argument (like X[i] or Y[10])
typedef struct {
    char* key;         // e.g., "X", "Y"
    ASTNode* indexExpr; // expression inside []
} GArg;

typedef enum {
    AST_NOP,
    AST_LET,
    AST_VAR,
    AST_INDEX,
    AST_NUMBER,
    AST_BINARY,
    AST_GCODE,
     AST_WHILE,
    AST_FOR,
    AST_BLOCK,
    AST_NOTE,
} ASTNodeType;

struct ASTNode {
    ASTNodeType type;

    union {

        struct { // binary expression: left + right
            TokenType op;
            ASTNode* left;
            ASTNode* right;
        } binary_expr;


struct {  // let x = expr
    char* name;
    ASTNode* expr;  // ✅ store the expression instead of value
} let_stmt;

        struct {  // variable reference: e.g., x
            char* name;
        } var;

struct {  // numeric constant
    double value;
} number;



        struct {  // array-style access: e.g., X[i]
            ASTNode* array;
            ASTNode* index;
        } index_expr;

        struct {  // G-code: e.g., G1 X[i] Y[0]
            char* code;  // "G1", "M3", etc.
            GArg* args;  // array of arguments
            int argCount;
        } gcode_stmt;


       struct {  // while condition { ... }
            ASTNode* condition;
            ASTNode* body;
        } while_stmt;



        struct {  // for i = 0..5 { ... }
            char* var;
                double from;
              double to;
            ASTNode* body;
        } for_stmt;

        struct {  // block: { ... }
            ASTNode** statements;
            int count;
        } block;

struct {  // note { ... }
    char* content;
} note;


    };
};

// Entry point
ASTNode* parse_script(const char* source);
void free_ast(ASTNode* node);

#endif // AST_NODES_H

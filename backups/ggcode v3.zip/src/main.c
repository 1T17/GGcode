#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <sys/resource.h>

#include "config.h"
#include "parser/parser.h"
#include "runtime/evaluator.h"
#include "utils/output_buffer.h"
#include "generator/gcode_emitter.h"
#include "utils/file_utils.h"
#include "utils/report.h"
#include "runtime/memory.h"

#include <string.h>


void compile_file(const char* input_path, const char* output_path, int debug) {
    long input_size_bytes = 0;

    char* source = read_file_to_buffer(input_path, &input_size_bytes);
    if (!source) {
        perror("Failed to read input file");
        exit(1);
    }

    init_output_buffer();

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    ASTNode* root = parse_script(source);
    clock_gettime(CLOCK_MONOTONIC, &end);
    double parse_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    // ➤ Emit G-code (this defines variables like 'id')
    clock_gettime(CLOCK_MONOTONIC, &start);





    
    emit_gcode(root, debug);
    clock_gettime(CLOCK_MONOTONIC, &end);
    double emit_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    // ➤ Insert G-code header at the beginning AFTER emit
    char preamble[128] = "%\n";
    char id_line[64];


    fprintf(stderr, "[DEBUG] id = %s\n", id_line);

    if (exists_variable("id")) {
        
        snprintf(id_line, sizeof(id_line), "%.0f", get_variable_value("id"));
    } else {
        snprintf(id_line, sizeof(id_line), "09090909090");
    }
    strcat(preamble, id_line);
    strcat(preamble, "\n");

    // ➤ Insert preamble at start of output buffer
    prepend_to_output_buffer(preamble);  // You need to implement this

    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    long memory_kb = usage.ru_maxrss;

    if (get_output_to_file()) {
        FILE* out = fopen(output_path, "w");
        if (!out) {
            perror("Failed to write output file");
        } else {
            fwrite(get_output_buffer(), 1, get_output_length(), out);
            fclose(out);
        }
    } else {
        printf("%s", get_output_buffer());
    }

    long gcode_size_bytes = get_output_length();
    print_compilation_report(input_size_bytes, gcode_size_bytes, parse_time, emit_time, memory_kb, get_statement_count());

    free_ast(root);
    free(source);
    free_output_buffer();
}


int main() {
    compile_file(get_input_file(), get_output_file(), get_debug());
    return 0;
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "gcode_emitter.h"
#include "runtime/evaluator.h"
#include "utils/output_buffer.h"
#include "config.h"

int statement_count = 0;

int get_statement_count() {
    return statement_count;
}

void emit_gcode(ASTNode* node, int debug) {
    if (!node) {
        fprintf(stderr, "[Emit] ERROR: NULL node passed to emit_gcode\n");
        return;
    }

    if (node->type < 0 || node->type > AST_NOTE) {
        fprintf(stderr, "[Emit] ERROR: Invalid AST node type: %d\n", node->type);
        return;
    }

    switch (node->type) {

case AST_NOTE: {
    statement_count++;

    if (!node->note.content) {
        fprintf(stderr, "[Emit] WARNING: NOTE content is NULL\n");
        return;
    }

    if (debug) {
        printf("[Emit] NOTE (raw content): %s\n", node->note.content);
        fflush(stdout);
    }

    // Copy and parse note line by line
    char* note = strdup(node->note.content);
    if (!note) {
        fprintf(stderr, "[Emit] ERROR: strdup failed for note content\n");
        return;
    }

    char* line = strtok(note, "\n");
    while (line) {
        char parsed[256] = {0};
        const char* p = line;
        char* out = parsed;

        while (*p) {
            if (*p == '[') {
                p++;  // skip '['
                char varname[64] = {0};
                int vi = 0;
                while (*p && *p != ']' && vi < 63) {
                    varname[vi++] = *p++;
                }
                varname[vi] = '\0';
                if (*p == ']') p++; // skip ']'

                double val = get_var(varname);
                char valstr[32];
                snprintf(valstr, sizeof(valstr), "%.6g", val);
                strcat(out, valstr);
                out += strlen(valstr);
            } else {
                *out++ = *p++;
            }
        }
        *out = '\0';

        char gcode_comment[300];
        snprintf(gcode_comment, sizeof(gcode_comment), "(%s)", parsed);
        write_to_output(gcode_comment);

        line = strtok(NULL, "\n");
    }

    free(note);
    break;
}

        case AST_LET:
            if (!node->let_stmt.name) {
                fprintf(stderr, "[Emit] ERROR: LET statement missing name\n");
                return;
            }

            if (debug) {
                printf("[Emit] LET %s = %.5f\n", node->let_stmt.name, node->let_stmt.value);
                fflush(stdout);
            }

            set_var(node->let_stmt.name, node->let_stmt.value);
            break;

        case AST_GCODE: {
            statement_count++;

            if (!node->gcode_stmt.code) {
                fprintf(stderr, "[Emit] ERROR: GCODE missing command code\n");
                return;
            }

            if (debug) {
                printf("[Emit] GCODE %s\n", node->gcode_stmt.code);
                fflush(stdout);
            }

            static char last_code[16] = "";
            char line[256] = {0};

            if (get_enable_n_lines()) {
                snprintf(line, sizeof(line), "N%d ", get_line_number());
                increment_line_number();
            }

            if (strcmp(node->gcode_stmt.code, "G1") == 0) {
                if (strcmp(last_code, "G1") != 0) {
                    strcat(line, "G1");
                    strcpy(last_code, "G1");
                }
            } else {
                strcat(line, node->gcode_stmt.code);
                strncpy(last_code, node->gcode_stmt.code, sizeof(last_code) - 1);
                last_code[sizeof(last_code) - 1] = '\0';
            }

            for (int i = 0; i < node->gcode_stmt.argCount; i++) {
                char segment[64];
                double val = 0.0;

                if (node->gcode_stmt.args[i].indexExpr) {
                    val = eval_expr(node->gcode_stmt.args[i].indexExpr);
                }

                snprintf(segment, sizeof(segment), " %s%.6g", node->gcode_stmt.args[i].key, val);
                strcat(line, segment);
            }

            if (debug) {
                printf("[Line] Final G-code: %s\n", line);
                fflush(stdout);
            }

            write_to_output(line);
            break;
        }

        case AST_FOR:
            if (!node->for_stmt.var || !node->for_stmt.body) {
                fprintf(stderr, "[Emit] ERROR: FOR loop missing variable or body\n");
                return;
            }

            if (debug) {
                printf("[Emit] FOR %s = %.2f .. %.2f\n", node->for_stmt.var, node->for_stmt.from, node->for_stmt.to);
                fflush(stdout);
            }

            for (int i = node->for_stmt.from; i <= node->for_stmt.to; i++) {
                set_var(node->for_stmt.var, i);
                emit_gcode(node->for_stmt.body, debug);
            }
            break;

        case AST_BLOCK:
            if (debug) {
                printf("[Emit] BLOCK with %d statements\n", node->block.count);
                fflush(stdout);
            }

            for (int i = 0; i < node->block.count; i++) {
                if (!node->block.statements[i]) {
                    fprintf(stderr, "[Emit] WARNING: NULL statement in block index %d\n", i);
                    continue;
                }

                if (debug) {
                    printf("[Emit] → Emitting statement %d / %d (type %d)\n", i + 1, node->block.count, node->block.statements[i]->type);
                    fflush(stdout);
                }

                emit_gcode(node->block.statements[i], debug);
            }
            break;

        default:
            fprintf(stderr, "[Emit] WARNING: Unrecognized node type: %d\n", node->type);
            break;
    }
}

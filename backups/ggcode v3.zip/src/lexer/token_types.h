#ifndef TOKEN_TYPES_H
#define TOKEN_TYPES_H

typedef enum {

    TOKEN_LBRACKET,  // [
    TOKEN_RBRACKET,  // ]

    // Keywords
    TOKEN_LET,
    TOKEN_FUNCTION,
    TOKEN_FOR,
    TOKEN_WHILE,
    TOKEN_IF,
    TOKEN_ELSE,
    TOKEN_RETURN,
    TOKEN_IMPORT,
    TOKEN_NOTE,       // 'note'

    // Identifiers and literals
    TOKEN_IDENTIFIER,
    TOKEN_NUMBER,

    // Operators
    TOKEN_PLUS,
    TOKEN_MINUS,
    TOKEN_STAR,
    TOKEN_SLASH,
    TOKEN_EQUAL,
    TOKEN_DOUBLE_EQUAL,
    TOKEN_NOT_EQUAL,
    TOKEN_LESS,
    TOKEN_LESS_EQUAL,
    TOKEN_GREATER,
    TOKEN_GREATER_EQUAL,

    // Delimiters
    TOKEN_LPAREN,
    TOKEN_RPAREN,
    TOKEN_LBRACE,
    TOKEN_RBRACE,
    TOKEN_COMMA,
    TOKEN_SEMICOLON,

    // G-code specific
    TOKEN_GCODE_WORD, // G0, G1, G2, M3, etc.

    // Range and special
    TOKEN_DOTDOT,     // '..' range operator
    TOKEN_DOT,        // single '.'


    // Custom
    TOKEN_BLOCK_COMMENT,  // ✅ NEW: For /% %/ multiline G-code comment blocks


    // Special
    TOKEN_EOF,
    TOKEN_UNKNOWN
    
} TokenType;

#endif // TOKEN_TYPES_H

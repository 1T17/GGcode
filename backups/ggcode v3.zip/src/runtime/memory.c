#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_VARIABLES 1024

typedef struct {
    char name[64];
    double value;
} Variable;

static Variable variables[MAX_VARIABLES];
static int variable_count = 0;

void define_variable(const char* name, double value) {
    for (int i = 0; i < variable_count; i++) {
        if (strcmp(variables[i].name, name) == 0) {
            variables[i].value = value;
            return;
        }
    }
    if (variable_count < MAX_VARIABLES) {
        strncpy(variables[variable_count].name, name, sizeof(variables[variable_count].name) - 1);
        variables[variable_count].value = value;
        variable_count++;
    } else {
        fprintf(stderr, "[Runtime Error] Variable store limit reached.\n");
    }
}

int exists_variable(const char* name) {
    for (int i = 0; i < variable_count; i++) {
        if (strcmp(variables[i].name, name) == 0) {
            return 1;
        }
    }
    return 0;
}

double get_variable_value(const char* name) {
    for (int i = 0; i < variable_count; i++) {
        if (strcmp(variables[i].name, name) == 0) {
            return variables[i].value;
        }
    }
    fprintf(stderr, "[Runtime Error] Undefined variable: '%s'\n", name);
    return 0;
}

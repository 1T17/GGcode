#ifndef MEMORY_H
#define MEMORY_H

void define_variable(const char* name, double value);
int exists_variable(const char* name);
double get_variable_value(const char* name);

#endif // MEMORY_H

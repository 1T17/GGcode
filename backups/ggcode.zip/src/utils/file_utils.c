// utils/file_utils.c
#include <stdio.h>
#include <stdlib.h>
#include "file_utils.h"

char* read_file_to_buffer(const char* filename, long* size_out) {
    FILE* file = fopen(filename, "r");
    if (!file) return NULL;

    fseek(file, 0, SEEK_END);
    long size = ftell(file);
    rewind(file);

    char* buffer = malloc(size + 1);
    if (!buffer) {
        fclose(file);
        return NULL;
    }

    fread(buffer, 1, size, file);
    buffer[size] = '\0';
    fclose(file);

    if (size_out) *size_out = size;
    return buffer;
}

// utils/file_utils.h
char* read_file_to_buffer(const char* filename, long* size_out);

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/resource.h>

#include "config.h"
#include "parser/parser.h"
#include "runtime/evaluator.h"
#include "utils/output_buffer.h"
#include "generator/gcode_emitter.h"
#include "utils/file_utils.h"
#include "utils/report.h"

int debug = DEFAULT_DEBUG;
int output_to_file = DEFAULT_OUTPUT_TO_FILE;

int main(int argc, char* argv[]) {
    const char* input_file = (argc > 1) ? argv[1] : DEFAULT_INPUT_FILE;
    const char* output_file = (argc > 2) ? argv[2] : DEFAULT_OUTPUT_FILE;

    long input_size_bytes = 0;
    char* source = read_file_to_buffer(input_file, &input_size_bytes);
    if (!source) {
        fprintf(stderr, " Failed to read input file: %s\n", input_file);
        return 1;
    }

    init_output_buffer(); 

    struct timespec start, end;
    clock_gettime(CLOCK_MONOTONIC, &start);
    ASTNode* root = parse_script(source);
    clock_gettime(CLOCK_MONOTONIC, &end);
    double parse_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    clock_gettime(CLOCK_MONOTONIC, &start);
    emit_gcode(root, debug);
    clock_gettime(CLOCK_MONOTONIC, &end);
    double emit_time = (end.tv_sec - start.tv_sec) + (end.tv_nsec - start.tv_nsec) / 1e9;

    struct rusage usage;
    getrusage(RUSAGE_SELF, &usage);
    long memory_kb = usage.ru_maxrss;

    if (output_to_file) {
        FILE* out = fopen(output_file, "w");
        if (!out) {
            fprintf(stderr, " Failed to write output file: %s\n", output_file);
        } else {
            fwrite(get_output_buffer(), 1, get_output_length(), out);
            fclose(out);
        }
    } else {
        printf("%s", get_output_buffer());
    }

    long gcode_size_bytes = get_output_length();
    print_compilation_report(input_size_bytes, gcode_size_bytes, parse_time, emit_time, memory_kb, get_statement_count());

    free_ast(root);
    free(source);
    free_output_buffer();
    return 0;
}

#ifndef CONFIG_H
#define CONFIG_H

// Default configuration
#define DEFAULT_INPUT_FILE      "test.gg"
#define DEFAULT_OUTPUT_FILE     "output.gg"
#define DEFAULT_DEBUG           0   // 1 = enable debug logging
#define DEFAULT_OUTPUT_TO_FILE  1   // 1 = output to file, 0 = print to stdout

#endif // CONFIG_H

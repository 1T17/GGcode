#!/bin/bash

echo "📊 GGcode C Code Report"
echo "==============================="

# Optional flag to include test files
INCLUDE_TESTS=false
if [[ "$1" == "--t" ]]; then
    INCLUDE_TESTS=true
fi

# Define paths
INCLUDE_DIR="include"
SRC_DIR="src"
TEST_DIR="tests"

# Build file list based on flag
if $INCLUDE_TESTS; then
    echo "🔎 Including test files..."
    files=$(find "$INCLUDE_DIR" "$SRC_DIR" "$TEST_DIR" \
        \( -path "$TEST_DIR/Unity" -o -path "$TEST_DIR/Unity/*" \) -prune -false -o \
        \( -name "*.c" -o -name "*.h" \))
else
    echo "🔎 Skipping test files..."
    files=$(find "$INCLUDE_DIR" "$SRC_DIR" \
        \( -name "*.c" -o -name "*.h" \))
fi

# Init counters
total_lines=0
total_comments=0
total_functions=0
file_count=0
total_bytes=0

for file in $files; do
    file_count=$((file_count + 1))
    lines=$(wc -l < "$file")
    comments=$(grep -E '^\s*//|^\s*/\*|^\s*\*' "$file" | wc -l)
    functions=$(grep -E '^[a-zA-Z_][a-zA-Z0-9_ *]+\([^\)]*\)[[:space:]]*\{' "$file" | wc -l)
    bytes=$(wc -c < "$file")

    total_lines=$((total_lines + lines))
    total_comments=$((total_comments + comments))
    total_functions=$((total_functions + functions))
    total_bytes=$((total_bytes + bytes))

    echo "📄 $file"
    echo "   🔹 Lines     : $lines"
    echo "   🔹 Functions : $functions"
    echo "   🔹 Comments  : $comments"
    echo "   🔹 Bytes     : $bytes"
    echo
done

# Human-readable size
human_size=$(numfmt --to=iec-i --suffix=B <<< $total_bytes)
code_lines=$((total_lines - total_comments))
avg_lines_per_file=$((total_lines / file_count))
avg_func_size=$((total_lines / (total_functions > 0 ? total_functions : 1)))

echo "==============================="
echo "📦 Total Files     : $file_count"
echo "📏 Total Lines     : $total_lines"
echo "🧩 Total Functions : $total_functions"
echo "💬 Total Comments  : $total_comments"
echo "🔢 Total Bytes     : $total_bytes ($human_size)"
echo "📊 Code Only Lines : $code_lines"
echo "📈 Avg Lines/File  : $avg_lines_per_file"
echo "📉 Avg Func Size   : $avg_func_size"
echo "==============================="
